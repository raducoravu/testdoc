# Installing ZIGI

-   **[Using Git](zOS_ISPF_Git_Interface_Users_Guide_V3R0_using_git.md)**  

-   **[Using CBTTape](zOS_ISPF_Git_Interface_Users_Guide_V3R0_using_cbttape.md)**  


**Parent topic:**[zOS\_ISPF\_Git\_Interface\_Users\_Guide\_V3R0\_d5e1.md](zOS_ISPF_Git_Interface_Users_Guide_V3R0_d5e1.md)

