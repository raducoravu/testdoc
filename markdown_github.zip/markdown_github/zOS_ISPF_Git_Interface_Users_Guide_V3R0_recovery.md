# Recovery

The historical recovery prompts for a recovery dataset if that dataset should be allocated new, and then a confirmation of the recovery. Recovery can occur in the active dataset if desired but with an additional confirmation prompt.

![](media/img(76).png)

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

