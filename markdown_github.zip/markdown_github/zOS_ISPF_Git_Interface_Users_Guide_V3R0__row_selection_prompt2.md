# / Row Selection Prompt

If a / is entered for a row selection, a pop-up menu prompt aids the user:

![](media/img(77).png)

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

