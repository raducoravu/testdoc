# Add option

The Add option adds the dataset, if sequential, or any modified members of a partitioned dataset, to the git index which makes them available to be committed.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

