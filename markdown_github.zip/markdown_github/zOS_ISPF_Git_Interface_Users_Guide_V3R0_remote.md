# Remote

The Remote command is used for newly [created](#_Create) local repositories to be associated with a remote repository.

![](media/img(54).png)

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

