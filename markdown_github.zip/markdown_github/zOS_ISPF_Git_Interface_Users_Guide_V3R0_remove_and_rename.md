# Remove and Rename

See the previous discussion about [Remove](#_Remove_(RM)_1) and [Rename](#_Rename_(RN)) which applies, in this case, just to the PDS Member.

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

