# View Option

Using V \([view](#_View)\) opens the ISPF 3.17 \(UDList\) on the repositories OMVS filesystem.

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

