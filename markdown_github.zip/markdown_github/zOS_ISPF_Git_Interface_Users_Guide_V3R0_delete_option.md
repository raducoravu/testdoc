# Delete Option

The Delete option deletes the local repository from the OMVS filesystem while leaving the z/OS datasets untouched.

![](media/img(24).png)

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

