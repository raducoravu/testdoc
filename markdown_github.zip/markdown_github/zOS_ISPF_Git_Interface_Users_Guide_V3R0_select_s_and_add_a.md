# Select \(S\) and Add \(A\)

These selections add the dataset as text data, or if RECFM=U, as a binary executable which includes tagging the file as binary and updating the .gitattributes file accordingly.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

