# Pre-Requisites \(Installing Git\)

See [Appendix A](#_Appendix_A_%2013) for a checklist for installing Git and the additional tools that it requires – all open source and all for free.

![](media/img.tif)

*Figure 1. Overview of Git Processing*

**Parent topic:**[Overview \(What You Should Know but May Not\)](zOS_ISPF_Git_Interface_Users_Guide_V3R0_overview_what_you_should_know_but_may_not.md)

