# Appendix C: Learning Resources

The following are some links to webpages to learn more about Git:

-   [https://danielmiessler.com/study/git/](https://danielmiessler.com/study/git/)
-   [https://www.atlassian.com/git](https://www.atlassian.com/git)
-   [https://git-scm.com/](https://git-scm.com/)
-   [http://rogerdudler.github.io/git-guide/](http://rogerdudler.github.io/git-guide/)
-   [https://guides.github.com/introduction/git-handbook/\#basic-git](https://guides.github.com/introduction/git-handbook/)
-   [https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf](https://github.github.com/training-kit/downloads/github-git-cheat-sheet.pdf)
-   Numerous links: [https://try.github.io/](https://try.github.io/)

**Parent topic:**[zOS\_ISPF\_Git\_Interface\_Users\_Guide\_V3R0\_d5e1.md](zOS_ISPF_Git_Interface_Users_Guide_V3R0_d5e1.md)

