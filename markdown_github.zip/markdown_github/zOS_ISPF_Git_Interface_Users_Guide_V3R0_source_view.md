# Source View

![](media/img(75).png)

This view of the source is from that specific commit. It is placed into a z/OS dataset to allow the user to use the ISPF Edit Compare, Create, and Copy commands, among others.

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

