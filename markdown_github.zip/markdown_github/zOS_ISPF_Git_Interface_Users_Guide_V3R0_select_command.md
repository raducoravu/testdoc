# Select Command

For those who don’t want to tab to a row, move the cursor to a row, use point-and-shoot, or enter S to select a repository, there is a command option to directly select a repository to be opened.

Syntax: Select repository-name

Select may be abbreviated as S and must be followed by the repository name. For the Select command, the search is case insensitive.

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

