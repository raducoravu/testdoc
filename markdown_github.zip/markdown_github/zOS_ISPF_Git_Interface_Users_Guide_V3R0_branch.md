# Branch

The Branch command allows the user to change to a different repository. If the branch does not exist the user may create it \(effectively performing a checkout -b\), if it exists the user may check out that branch with the C line command.

![](media/img(34).png)

NOTE: The status column indicates if the branch is only on the Remote server, or if there is a copy locally \(Local/Remote\).

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

