# Select option

The Select option, or point-and-shoot, performs one of two different actions depending upon the type of dataset being selected.

Edit a sequential dataset. After the edit, if the data has changed, it is copied down to the OMVS file.

Open an Edit member list for a PDS – see the next [chapter](#_Un-Modify) for more information.

If the selected file is an OMVS directory, then ZIGI opens that directory and displays it using the Current Repository routines.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

