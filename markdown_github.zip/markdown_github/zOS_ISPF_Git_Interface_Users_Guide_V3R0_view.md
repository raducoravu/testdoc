# View

The View command invokes the ISPF 3.17 \(UDList\) service on the active local repository filesystem.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

