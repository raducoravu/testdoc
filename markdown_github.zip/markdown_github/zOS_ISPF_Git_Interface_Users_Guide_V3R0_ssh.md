# SSH

This command displays your SSH public key so that it can be easily copied and then pasted into your GitHub \(or equivalent\) user profile settings to enable easy access to the remote repository. There is no concern about sharing your public key since it must be used in concert with your private key which you should **never share** with anyone.

![](media/img(22).png)

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

