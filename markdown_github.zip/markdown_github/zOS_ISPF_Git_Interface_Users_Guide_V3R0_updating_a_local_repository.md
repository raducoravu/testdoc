# Updating a Local Repository

*Need prose*

**Parent topic:**[Typical ZIGI Activities](zOS_ISPF_Git_Interface_Users_Guide_V3R0_typical_zigi_activities.md)

