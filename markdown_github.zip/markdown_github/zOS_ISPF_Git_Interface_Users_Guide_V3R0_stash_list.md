# Stash List

STASHL, or Stash list, lists all stashes in the current repository and provides a number of options.

![](media/img(58).png)

Available commands with Stash List are currently limited to one at this time:

The **Clear** command removes all stashes in the current repository. Use this only if you are positive you don’t need them anymore.

The available line commands are available in this line selection pop-up by entering a / in the row selection field:

![](media/img(59).png)

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

