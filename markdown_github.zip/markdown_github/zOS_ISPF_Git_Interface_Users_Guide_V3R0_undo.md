# Undo

Undo reverts any changes made to a PDS member before a commit. This means the status is \[M\}, \{M\], or \[MM\].

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

