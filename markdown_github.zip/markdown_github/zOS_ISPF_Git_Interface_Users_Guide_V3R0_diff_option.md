# Diff Option

Compares the active file in the OMVS filesystem with the last index for the file.

![](media/img(71).png)

The diff is displayed using ISPF View that has been enhanced to highlight the additions and deletions in the file. If there have been no changes since the last commit, then there is nothing to compare.

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

