# Rename \(RN\)

The Rename command renames the z/OS dataset, the OMVS file, or the OMVS directory and updates Git. NOTE: Git does not retain any of the Git histories from the original name.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

