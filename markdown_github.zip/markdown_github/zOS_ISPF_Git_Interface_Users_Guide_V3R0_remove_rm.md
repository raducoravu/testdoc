# Remove \(RM\)

Remove deletes the z/OS dataset, the OMVS file, or the OMVS directory. It also deletes it from Git management. This can be undone before, or after, commit processing using Rollback.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

