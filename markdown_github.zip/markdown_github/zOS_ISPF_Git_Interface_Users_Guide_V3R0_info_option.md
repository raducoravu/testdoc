# Info Option

The INFO option displays a short summary of information about the repository.

![](media/img(23).png)

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

