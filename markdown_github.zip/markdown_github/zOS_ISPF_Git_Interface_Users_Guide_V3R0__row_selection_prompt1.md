# / Row Selection Prompt

If a / is entered for a row selection, the following pop-up aids the user:

![](media/img(65).png)

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

