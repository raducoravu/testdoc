# Reset-IDs Command

This option prompts to change the userids of all members to a new userid. This is useful to hide the users userid or to make all userids conform to a standard for promoted elements.

![](media/img(69).png)

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

