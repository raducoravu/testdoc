# Action Bar Menu

The action bar menus are there to make it easy to access commands when you forget, or just want to use the mouse for point-and-shoot.

**Parent topic:**[The ZIGI Local Repositories Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_local_repositories_panel.md)

