# Grep

The Grep command prompts for a string and then searches the local repository for that string, displaying the results:

![](media/img(48).png)

And the results in Dataset view:

![](media/img(49).png)

The Dataset view presents each of the datasets, or dataset\(member\), where a hit was detected along with reporting how many hits were found in each. Browse, Edit, or View each.

And the results for the Report view:

![](media/img(50).png)

INFO displays a short summary of information about the repository.

![](media/img(51).png)

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

