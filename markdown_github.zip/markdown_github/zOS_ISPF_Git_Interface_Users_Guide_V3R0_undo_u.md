# Undo \(U\)

Undo reverts any changes made to a dataset or OMVS file before a commit. This means the status is \[M\}, \{M\], or \[MM\]. NOTE: Undo does not work on a full PDS – it only works on PDS members.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

