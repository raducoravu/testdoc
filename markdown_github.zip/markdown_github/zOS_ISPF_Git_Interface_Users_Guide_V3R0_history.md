# History

View a history of commits for the dataset, or file, with an option to view the source as of the historical point in time. See the [History option](#_History_option) for more information.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

