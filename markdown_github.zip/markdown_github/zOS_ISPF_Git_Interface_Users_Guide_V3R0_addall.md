# AddAll

The AddAll command adds all Modified and UnTracked datasets and files to the Git staging index, which makes them ready for the next Git Commit.

This is performed using the **git add .** command.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

