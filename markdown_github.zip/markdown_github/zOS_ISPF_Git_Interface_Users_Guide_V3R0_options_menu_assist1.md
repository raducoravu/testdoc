# Options Menu Assist

Use O on the command line to bring up a pop-up menu of all available commands. This is useful if the user has selected to use the Pro or Hidden menu.

![](media/img(53).png)

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

