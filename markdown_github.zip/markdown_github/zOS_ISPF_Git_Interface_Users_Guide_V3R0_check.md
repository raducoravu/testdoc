# Check

The Check command checks all z/OS datasets, based on the last reference date from the DSCB, to determine if the data has changed since the repository was opened. This is useful if the repository has been open for a period of time and the repository datasets have been updated outside of ZIGI.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

