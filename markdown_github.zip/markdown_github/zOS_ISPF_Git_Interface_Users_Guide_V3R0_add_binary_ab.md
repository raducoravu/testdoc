# Add Binary \(AB\)

Add Binary adds the entire dataset as binary data. This includes tagging the OMVS copy of the dataset with the binary tag \(chtag\) and updating the .gitattributes file for the file. If the dataset is a partitioned dataset that contains both text and binary members: Select or Add the entire dataset, then from the Current Repository display select the PDS, and from the Member list AB the individual members that are in binary format.

**Parent topic:**[The ZIGI Current Repository Panel](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_current_repository_panel.md)

