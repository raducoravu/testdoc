# History Option

History shows a selectable list of all commits for the selected member. From this list, the full source from that point in time may be viewed, or the commit with diffs can be viewed:

![](media/img(72).png)

The row selection of / displays a pop-up to guide the selection of the row command:

![](media/img(73).png)

**Parent topic:**[The ZIGI PDS Member List](zOS_ISPF_Git_Interface_Users_Guide_V3R0_the_zigi_pds_member_list.md)

